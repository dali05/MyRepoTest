package com.example.client.storage;
import com.example.common.storage.s3.StorageService;
import org.springframework.web.bind.annotation.*;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

@RestController
@RequestMapping("/storage")
public class StorageController {
    private final StorageService storage;
    public StorageController(StorageService storage) { this.storage = storage; }

    @PostMapping("/{bucket}/{key}")
    public String upload(@PathVariable String bucket, @PathVariable String key, @RequestBody String content) {
        InputStream input = new ByteArrayInputStream(content.getBytes());
        storage.putObject(bucket, key, input, content.length(), "text/plain");
        return "✅ Uploaded " + key + " to " + bucket;
    }

    @GetMapping("/{bucket}/{key}")
    public String download(@PathVariable String bucket, @PathVariable String key) throws Exception {
        try (InputStream in = storage.getObject(bucket, key)) {
            return new String(in.readAllBytes());
        }
    }

    @DeleteMapping("/{bucket}/{key}")
    public String delete(@PathVariable String bucket, @PathVariable String key) {
        storage.deleteObject(bucket, key);
        return "🗑️ Deleted " + key + " from " + bucket;
    }
}
