package com.example.client.db;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class HelloRepository {
    private final JdbcTemplate jdbcTemplate;
    public HelloRepository(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }
    public List<String> findMessages() {
        return jdbcTemplate.queryForList("SELECT message FROM demo_hello", String.class);
    }
}
