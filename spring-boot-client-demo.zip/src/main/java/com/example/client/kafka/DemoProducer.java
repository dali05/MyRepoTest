package com.example.client.kafka;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class DemoProducer {
    private final KafkaTemplate<String, Object> kafkaTemplate;
    public DemoProducer(KafkaTemplate<String, Object> kafkaTemplate) { this.kafkaTemplate = kafkaTemplate; }
    public void send(String topic, String msg) { kafkaTemplate.send(topic, msg); }
}
