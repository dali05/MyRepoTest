package com.example.common.postgres;

import javax.sql.DataSource;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@AutoConfiguration
@EnableConfigurationProperties(PostgresProperties.class)
@ConditionalOnClass({DataSource.class, JdbcTemplate.class})
@ConditionalOnProperty(prefix = "common.postgres", name = "enabled", havingValue = "true", matchIfMissing = true)
public class PostgresAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public DataSource dataSource(PostgresProperties props) {
    DriverManagerDataSource ds = new DriverManagerDataSource();
    ds.setDriverClassName("org.postgresql.Driver");
    ds.setUrl(props.getUrl());
    ds.setUsername(props.getUsername());
    ds.setPassword(props.getPassword());
    return ds;
  }

  @Bean
  @ConditionalOnMissingBean
  public JdbcTemplate jdbcTemplate(DataSource dataSource) {
    return new JdbcTemplate(dataSource);
  }
}
