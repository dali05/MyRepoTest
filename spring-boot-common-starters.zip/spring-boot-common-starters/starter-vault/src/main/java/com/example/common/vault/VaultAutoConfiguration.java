package com.example.common.vault;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

/**
 * Spring Cloud Vault mostly configures itself via properties.
 * This class acts as a switch to enable 'spring.config.import=vault:' automatically (Boot 3.1+).
 */
@AutoConfiguration
@ConditionalOnProperty(prefix = "common.vault", name = "enabled", havingValue = "true", matchIfMissing = true)
@Configuration
public class VaultAutoConfiguration {
  // No explicit beans required; presence of dependency + properties will activate Vault property source.
}
