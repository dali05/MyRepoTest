package com.example.common.core;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@AutoConfiguration
@EnableConfigurationProperties(CoreProperties.class)
@ConditionalOnProperty(prefix = "common.core", name = "enabled", havingValue = "true", matchIfMissing = true)
public class CoreAutoConfiguration {
    // place for common beans (tracing, object mappers, etc.) later
}
