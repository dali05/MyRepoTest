package com.example.common.core;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "common.core")
public record CoreProperties(boolean enabled) {
    public static final boolean DEFAULT_ENABLED = true;
    public CoreProperties() { this(DEFAULT_ENABLED); }
}
