package com.example.common.liquibase;

import javax.sql.DataSource;
import liquibase.integration.spring.SpringLiquibase;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(LiquibaseProperties.class)
@ConditionalOnProperty(prefix = "common.liquibase", name = "enabled", havingValue = "true", matchIfMissing = true)
public class LiquibaseAutoConfiguration {

  @Bean
  @ConditionalOnBean(DataSource.class)
  @ConditionalOnMissingBean
  public SpringLiquibase liquibase(DataSource dataSource, LiquibaseProperties props) {
    SpringLiquibase lb = new SpringLiquibase();
    lb.setDataSource(dataSource);
    lb.setChangeLog(props.getChangeLog());
    return lb;
  }
}
