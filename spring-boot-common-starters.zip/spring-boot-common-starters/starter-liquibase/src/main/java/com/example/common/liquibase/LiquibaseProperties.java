package com.example.common.liquibase;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "common.liquibase")
public class LiquibaseProperties {
  private boolean enabled = true;
  private String changeLog = "classpath:/db/changelog/db.changelog-master.yaml";
  public boolean isEnabled() { return enabled; }
  public void setEnabled(boolean enabled) { this.enabled = enabled; }
  public String getChangeLog() { return changeLog; }
  public void setChangeLog(String changeLog) { this.changeLog = changeLog; }
}
