package com.example.common.kafka;

import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.config.TopicBuilder;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

@AutoConfiguration
@EnableConfigurationProperties(KafkaAvroProperties.class)
@ConditionalOnClass({KafkaTemplate.class, KafkaAvroSerializer.class})
@ConditionalOnProperty(prefix = "common.kafka", name = "enabled", havingValue = "true", matchIfMissing = true)
public class KafkaAvroAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public ProducerFactory<String, Object> producerFactory(KafkaAvroProperties props) {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
    configProps.put("schema.registry.url", props.getSchemaRegistryUrl());
    if (props.getProducer() != null) configProps.putAll(props.getProducer());
    return new DefaultKafkaProducerFactory<>(configProps);
  }

  @Bean
  @ConditionalOnMissingBean
  public KafkaTemplate<String, Object> kafkaTemplate(ProducerFactory<String, Object> pf) {
    return new KafkaTemplate<>(pf);
  }

  // Example topic bean (opt-in with property)
  @Bean
  @ConditionalOnProperty(prefix="common.kafka.topic.example", name="name")
  public NewTopic exampleTopic(org.springframework.core.env.Environment env) {
    String name = env.getProperty("common.kafka.topic.example.name");
    int partitions = Integer.parseInt(env.getProperty("common.kafka.topic.example.partitions","1"));
    short replicas = Short.parseShort(env.getProperty("common.kafka.topic.example.replicas","1"));
    return TopicBuilder.name(name).partitions(partitions).replicas(replicas).build();
  }
}
