package com.example.common.kafka;

import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "common.kafka")
public class KafkaAvroProperties {
  private boolean enabled = true;
  private String bootstrapServers = "localhost:9092";
  private String schemaRegistryUrl = "http://localhost:8081";
  private Map<String, String> producer;
  private Map<String, String> consumer;
  public boolean isEnabled() { return enabled; }
  public void setEnabled(boolean enabled) { this.enabled = enabled; }
  public String getBootstrapServers() { return bootstrapServers; }
  public void setBootstrapServers(String bootstrapServers) { this.bootstrapServers = bootstrapServers; }
  public String getSchemaRegistryUrl() { return schemaRegistryUrl; }
  public void setSchemaRegistryUrl(String schemaRegistryUrl) { this.schemaRegistryUrl = schemaRegistryUrl; }
  public Map<String, String> getProducer() { return producer; }
  public void setProducer(Map<String, String> producer) { this.producer = producer; }
  public Map<String, String> getConsumer() { return consumer; }
  public void setConsumer(Map<String, String> consumer) { this.consumer = consumer; }
}
