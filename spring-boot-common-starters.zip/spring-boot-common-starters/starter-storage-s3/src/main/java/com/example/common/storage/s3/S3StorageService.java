package com.example.common.storage.s3;

import java.io.InputStream;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import java.net.URI;

public class S3StorageService implements StorageService {
  private final S3Client s3;
  public S3StorageService(S3Client s3) { this.s3 = s3; }

  @Override
  public void putObject(String bucket, String key, InputStream data, long contentLength, String contentType) {
    PutObjectRequest req = PutObjectRequest.builder().bucket(bucket).key(key).contentType(contentType).build();
    s3.putObject(req, RequestBody.fromInputStream(data, contentLength));
  }

  @Override
  public InputStream getObject(String bucket, String key) {
    return s3.getObject(GetObjectRequest.builder().bucket(bucket).key(key).build());
  }

  @Override
  public void deleteObject(String bucket, String key) {
    s3.deleteObject(DeleteObjectRequest.builder().bucket(bucket).key(key).build());
  }
}
