package com.example.common.storage.s3;

import java.io.InputStream;

public interface StorageService {
  void putObject(String bucket, String key, InputStream data, long contentLength, String contentType);
  InputStream getObject(String bucket, String key);
  void deleteObject(String bucket, String key);
}
