package com.example.common.storage.s3;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "common.storage.s3")
public class S3StorageProperties {
  private boolean enabled = true;
  private String endpoint; // e.g. http://localhost:9000 for MinIO
  private String region = "us-east-1";
  private String accessKey;
  private String secretKey;
  private boolean pathStyleAccess = true;
  public boolean isEnabled() { return enabled; }
  public void setEnabled(boolean enabled) { this.enabled = enabled; }
  public String getEndpoint() { return endpoint; }
  public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
  public String getRegion() { return region; }
  public void setRegion(String region) { this.region = region; }
  public String getAccessKey() { return accessKey; }
  public void setAccessKey(String accessKey) { this.accessKey = accessKey; }
  public String getSecretKey() { return secretKey; }
  public void setSecretKey(String secretKey) { this.secretKey = secretKey; }
  public boolean isPathStyleAccess() { return pathStyleAccess; }
  public void setPathStyleAccess(boolean pathStyleAccess) { this.pathStyleAccess = pathStyleAccess; }
}
