package com.example.common.storage.s3;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;
import java.net.URI;

@AutoConfiguration
@EnableConfigurationProperties(S3StorageProperties.class)
@ConditionalOnProperty(prefix = "common.storage.s3", name = "enabled", havingValue = "true", matchIfMissing = true)
public class S3StorageAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public S3Client s3Client(S3StorageProperties props) {
    S3Configuration s3cfg = S3Configuration.builder()
        .pathStyleAccessEnabled(props.isPathStyleAccess())
        .build();

    S3Client.Builder builder = S3Client.builder()
        .region(Region.of(props.getRegion()))
        .serviceConfiguration(s3cfg);

    if (props.getEndpoint() != null && !props.getEndpoint().isBlank()) {
      builder = builder.endpointOverride(URI.create(props.getEndpoint()));
    }
    if (props.getAccessKey() != null && props.getSecretKey() != null) {
      builder = builder.credentialsProvider(StaticCredentialsProvider.create(
        AwsBasicCredentials.create(props.getAccessKey(), props.getSecretKey())));
    }
    return builder.build();
  }

  @Bean
  @ConditionalOnMissingBean
  public StorageService storageService(S3Client client) {
    return new S3StorageService(client);
  }
}
