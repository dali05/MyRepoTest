# Common Starters (Storage, Kafka+Avro, Postgres, Vault, Liquibase)

Projet **professionnel** pour centraliser toute la configuration réutilisable.
Chaque module est un *Spring Boot Starter* avec **auto-configuration** et propriétés
`common.*`. Ajoutez simplement le starter voulu à votre service.

## Modules
- `starter-core` : base commune, point d'extension.
- `starter-postgres` : DataSource + JdbcTemplate (PostgreSQL).
- `starter-liquibase` : exécution Liquibase si un `DataSource` existe.
- `starter-kafka-avro` : `KafkaTemplate` avec sérialiseur Avro Confluent + création de topics optionnelle.
- `starter-storage-s3` : client S3 (AWS SDK v2) compatible MinIO + `StorageService`.
- `starter-vault` : intégration Spring Cloud Vault (activée par propriétés).

## Utilisation rapide
1. Construire/install : `mvn -q -DskipTests clean install`
2. Dans votre projet, ajoutez les dépendances nécessaires, ex. :
```xml
<dependency>
  <groupId>com.example</groupId><artifactId>starter-postgres</artifactId><version>1.0.0</version>
</dependency>
```
3. Paramétrez via `application.yaml` les clés `common.*` (voir `examples/consumer-demo`).

## Conventions
- Tous les starters sont **désactivables** via `common.<module>.enabled=false`.
- Pas de beans si vous les définissez vous‑même (`@ConditionalOnMissingBean`).

## Notes
- Kafka Avro nécessite un **Schema Registry** (Confluent) : `common.kafka.schema-registry-url`.
- Vault : Spring Cloud lit la conf via `spring.config.import=vault:` (déjà présent dans l'exemple).
- S3/MinIO : utilisez `endpoint` + `path-style-access=true` pour MinIO.

## Migration
Supprimez la conf dispersée (Kafka, S3, Postgres, Liquibase, Vault) de vos services et remplacez par ces starters.
Conservez uniquement les propriétés `common.*` dans `application.yaml` de chaque service.
