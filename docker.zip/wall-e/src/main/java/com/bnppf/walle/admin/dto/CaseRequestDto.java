package com.bnppf.walle.admin.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseRequestDto {

    @NotBlank
    @Size(max = 64)
    private String caseName;

    @NotNull
    private Boolean active;

    @NotBlank
    @Size(min = 2, max = 2)
    private String country;

    @NotNull
    private Integer retentionPeriod;

    @NotEmpty
    private List<@NotBlank String> dataSet;
}
