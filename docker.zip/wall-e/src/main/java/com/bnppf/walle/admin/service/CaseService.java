package com.bnppf.walle.admin.service;

import com.bnppf.walle.admin.dto.*;
import java.util.*;

public interface CaseService {
    CaseResponseDto createCase(CaseRequestDto dto);
    List<CaseResponseDto> getAllCases();
    CaseResponseDto getCaseById(UUID id);
    CaseResponseDto updateCase(UUID id, CaseRequestDto dto);
    void deleteCase(UUID id);
}
