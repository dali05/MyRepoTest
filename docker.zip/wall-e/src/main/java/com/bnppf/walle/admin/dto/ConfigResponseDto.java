package com.bnppf.walle.admin.dto;

import com.bnppf.walle.admin.model.Algorithm;
import com.bnppf.walle.admin.model.Mode;
import com.bnppf.walle.admin.model.NotificationType;
import com.lma.walle.admin.model.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConfigResponseDto {
    private UUID id;
    private Boolean kafkaNotification;
    private NotificationType notification;
    private String callbackUrl;
    private String oAuthTokenUrl;
    private String topicName;
    private Algorithm algorithm;
    private Mode mode;
    private LocalDateTime creationDate;
    private LocalDateTime updateDate;
}
