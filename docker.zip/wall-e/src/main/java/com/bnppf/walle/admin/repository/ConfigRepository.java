package com.bnppf.walle.admin.repository;

import com.bnppf.walle.admin.model.ConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ConfigRepository extends JpaRepository<ConfigEntity, UUID> {
}
