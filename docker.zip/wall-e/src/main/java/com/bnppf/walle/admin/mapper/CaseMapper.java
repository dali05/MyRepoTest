package com.bnppf.walle.admin.mapper;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.model.CaseEntity;
import org.springframework.stereotype.Component;

@Component
public class CaseMapper {

    public CaseEntity toEntity(CaseRequestDto dto) {
        return CaseEntity.builder()
                .caseName(dto.getCaseName())
                .active(dto.getActive())
                .country(dto.getCountry())
                .retentionPeriod(dto.getRetentionPeriod())
                .dataSet(dto.getDataSet())
                .build();
    }

    public CaseResponseDto toDto(CaseEntity entity) {
        return CaseResponseDto.builder()
                .id(entity.getId())
                .caseName(entity.getCaseName())
                .active(entity.getActive())
                .country(entity.getCountry())
                .retentionPeriod(entity.getRetentionPeriod())
                .dataSet(entity.getDataSet())
                .creationDate(entity.getCreationDate())
                .updateDate(entity.getUpdateDate())
                .build();
    }
}
