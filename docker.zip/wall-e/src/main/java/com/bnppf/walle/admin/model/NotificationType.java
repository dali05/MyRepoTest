package com.bnppf.walle.admin.model;

public enum NotificationType {
    API, KAFKA
}
