package com.bnppf.walle.admin.dto;

import lombok.*;
import java.time.LocalDateTime;
import java.util.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseResponseDto {
    private UUID id;
    private String caseName;
    private Boolean active;
    private String country;
    private Integer retentionPeriod;
    private List<String> dataSet;
    private LocalDateTime creationDate;
    private LocalDateTime updateDate;
}
