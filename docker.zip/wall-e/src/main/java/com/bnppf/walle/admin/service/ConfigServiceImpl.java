package com.bnppf.walle.admin.service;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.exception.NotFoundException;
import com.bnppf.walle.admin.mapper.ConfigMapper;
import com.bnppf.walle.admin.model.ConfigEntity;
import com.bnppf.walle.admin.repository.ConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ConfigServiceImpl implements ConfigService {

    private final ConfigRepository repository;
    private final ConfigMapper mapper;

    @Override
    public ConfigResponseDto createConfig(ConfigRequestDto dto) {
        log.info("Creating new configuration: algorithm={}, mode={}, notification={}",
                dto.getAlgorithm(), dto.getMode(), dto.getNotification());

        ConfigEntity entity = mapper.toEntity(dto);
        ConfigEntity saved = repository.save(entity);
        log.info("Configuration created successfully with id={}", saved.getId());
        return mapper.toDto(saved);
    }

    @Override
    public List<ConfigResponseDto> getAllConfigs() {
        log.info("Fetching all configurations");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public ConfigResponseDto getConfigById(UUID id) {
        log.info("Fetching configuration by id={}", id);
        ConfigEntity entity = repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Configuration not found for id=" + id));
        return mapper.toDto(entity);
    }

    @Override
    public ConfigResponseDto updateConfig(UUID id, ConfigRequestDto dto) {
        log.info("Updating configuration id={}", id);
        ConfigEntity existing = repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Configuration not found for id=" + id));

        existing.setKafkaNotification(dto.getKafkaNotification());
        existing.setNotification(dto.getNotification());
        existing.setCallbackUrl(dto.getCallbackUrl());
        existing.setOAuthTokenUrl(dto.getOAuthTokenUrl());
        existing.setTopicName(dto.getTopicName());
        existing.setAlgorithm(dto.getAlgorithm());
        existing.setMode(dto.getMode());

        ConfigEntity updated = repository.save(existing);
        log.info("Configuration updated successfully id={}", id);
        return mapper.toDto(updated);
    }

    @Override
    public void deleteConfig(UUID id) {
        log.info("Deleting configuration id={}", id);
        if (!repository.existsById(id)) {
            throw new NotFoundException("Configuration not found for id=" + id);
        }
        repository.deleteById(id);
        log.info("Configuration deleted successfully id={}", id);
    }
}
