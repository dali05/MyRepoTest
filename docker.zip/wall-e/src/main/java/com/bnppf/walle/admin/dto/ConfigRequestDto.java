package com.bnppf.walle.admin.dto;

import com.bnppf.walle.admin.model.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConfigRequestDto {

    @NotNull
    private Boolean kafkaNotification;

    @NotNull
    private NotificationType notification;

    private String callbackUrl;
    private String oAuthTokenUrl;
    private String topicName;

    @NotNull
    private Algorithm algorithm;

    @NotNull
    private Mode mode;
}
