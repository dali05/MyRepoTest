package com.bnppf.walle.admin.service;

import com.bnppf.walle.admin.dto.*;
import java.util.List;
import java.util.UUID;

public interface ConfigService {

    ConfigResponseDto createConfig(ConfigRequestDto dto);

    List<ConfigResponseDto> getAllConfigs();

    ConfigResponseDto getConfigById(UUID id);

    ConfigResponseDto updateConfig(UUID id, ConfigRequestDto dto);

    void deleteConfig(UUID id);
}
