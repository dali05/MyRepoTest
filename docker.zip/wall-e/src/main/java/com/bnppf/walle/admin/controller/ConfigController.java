package com.bnppf.walle.admin.controller;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.service.ConfigService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/config")
@RequiredArgsConstructor
@Slf4j
public class ConfigController {

    private final ConfigService service;

    @PostMapping
    public ResponseEntity<ConfigResponseDto> createConfig(
            @Valid @RequestBody ConfigRequestDto request,
            @RequestHeader(value = "x-authorization", required = false) String authHeader) {

        log.debug("Received POST /config request, header={}", authHeader);
        return ResponseEntity.status(201).body(service.createConfig(request));
    }

    @GetMapping
    public ResponseEntity<List<ConfigResponseDto>> getAllConfigs() {
        log.debug("Received GET /config request");
        return ResponseEntity.ok(service.getAllConfigs());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ConfigResponseDto> getConfigById(@PathVariable UUID id) {
        log.debug("Received GET /config/{}", id);
        return ResponseEntity.ok(service.getConfigById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ConfigResponseDto> updateConfig(
            @PathVariable UUID id,
            @Valid @RequestBody ConfigRequestDto request) {
        log.debug("Received PUT /config/{}", id);
        return ResponseEntity.ok(service.updateConfig(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteConfig(@PathVariable UUID id) {
        log.debug("Received DELETE /config/{}", id);
        service.deleteConfig(id);
        return ResponseEntity.noContent().build();
    }
}
