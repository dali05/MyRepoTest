package com.bnppf.walle.admin.model;

public enum Mode {
    JWT, MDOC
}
