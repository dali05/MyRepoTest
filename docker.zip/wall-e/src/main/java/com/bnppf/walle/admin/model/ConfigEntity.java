package com.bnppf.walle.admin.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "config")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConfigEntity extends BaseEntity {

    private Boolean kafkaNotification;

    @Enumerated(EnumType.STRING)
    private NotificationType notification;

    private String callbackUrl;
    private String oAuthTokenUrl;
    private String topicName;

    @Enumerated(EnumType.STRING)
    private Algorithm algorithm;

    @Enumerated(EnumType.STRING)
    private Mode mode;
}
