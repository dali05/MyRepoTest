package com.bnppf.walle.admin.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "\"case\"") // "case" est un mot réservé SQL
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseEntity extends BaseEntity {

    @Column(name = "case_name", length = 64, nullable = false)
    private String caseName;

    @Column(nullable = false)
    private Boolean active;

    @Column(length = 2, nullable = false)
    private String country;

    @Column(nullable = false)
    private Integer retentionPeriod;

    // Stockée sous forme CSV dans la BDD
    @ElementCollection
    @CollectionTable(name = "case_dataset", joinColumns = @JoinColumn(name = "case_id"))
    @Column(name = "dataset_value")
    private List<String> dataSet;
}
