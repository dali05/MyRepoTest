package com.bnppf.walle.admin.controller;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.service.CaseService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/case")
@RequiredArgsConstructor
@Slf4j
public class CaseController {

    private final CaseService service;

    @PostMapping
    public ResponseEntity<CaseResponseDto> createCase(@Valid @RequestBody CaseRequestDto request) {
        log.debug("POST /case request for {}", request.getCaseName());
        return ResponseEntity.status(201).body(service.createCase(request));
    }

    @GetMapping
    public ResponseEntity<List<CaseResponseDto>> getAllCases() {
        log.debug("GET /case request");
        return ResponseEntity.ok(service.getAllCases());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CaseResponseDto> getCaseById(@PathVariable UUID id) {
        log.debug("GET /case/{}", id);
        return ResponseEntity.ok(service.getCaseById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CaseResponseDto> updateCase(
            @PathVariable UUID id,
            @Valid @RequestBody CaseRequestDto request) {
        log.debug("PUT /case/{}", id);
        return ResponseEntity.ok(service.updateCase(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCase(@PathVariable UUID id) {
        log.debug("DELETE /case/{}", id);
        service.deleteCase(id);
        return ResponseEntity.noContent().build();
    }
}
