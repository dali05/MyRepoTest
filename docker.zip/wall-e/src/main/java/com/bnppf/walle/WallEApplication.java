package com.bnppf.walle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WallEApplication {

    public static void main(String[] args) {
        SpringApplication.run(WallEApplication.class, args);
    }

}
