package com.bnppf.walle.admin.model;

public enum Algorithm {
    ES256, ES384, ES512, ESB256, ESB320, ESB384, ESB512
}
