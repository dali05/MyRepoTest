package com.bnppf.walle.admin.mapper;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.model.ConfigEntity;
import org.springframework.stereotype.Component;

@Component
public class ConfigMapper {

    public ConfigEntity toEntity(ConfigRequestDto dto) {
        return ConfigEntity.builder()
                .kafkaNotification(dto.getKafkaNotification())
                .notification(dto.getNotification())
                .callbackUrl(dto.getCallbackUrl())
                .oAuthTokenUrl(dto.getOAuthTokenUrl())
                .topicName(dto.getTopicName())
                .algorithm(dto.getAlgorithm())
                .mode(dto.getMode())
                .build();
    }

    public ConfigResponseDto toDto(ConfigEntity entity) {
        return ConfigResponseDto.builder()
                .id(entity.getId())
                .kafkaNotification(entity.getKafkaNotification())
                .notification(entity.getNotification())
                .callbackUrl(entity.getCallbackUrl())
                .oAuthTokenUrl(entity.getOAuthTokenUrl())
                .topicName(entity.getTopicName())
                .algorithm(entity.getAlgorithm())
                .mode(entity.getMode())
                .creationDate(entity.getCreationDate())
                .updateDate(entity.getUpdateDate())
                .build();
    }
}
