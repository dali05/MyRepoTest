package com.bnppf.walle.admin.service;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.exception.NotFoundException;
import com.bnppf.walle.admin.mapper.CaseMapper;
import com.bnppf.walle.admin.model.CaseEntity;
import com.bnppf.walle.admin.repository.CaseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CaseServiceImpl implements CaseService {

    private final CaseRepository repository;
    private final CaseMapper mapper;

    @Override
    public CaseResponseDto createCase(CaseRequestDto dto) {
        log.info("Creating new case {}", dto.getCaseName());
        CaseEntity entity = mapper.toEntity(dto);
        CaseEntity saved = repository.save(entity);
        log.info("Case created with id={}", saved.getId());
        return mapper.toDto(saved);
    }

    @Override
    public List<CaseResponseDto> getAllCases() {
        log.info("Fetching all cases");
        return repository.findAll().stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public CaseResponseDto getCaseById(UUID id) {
        log.info("Fetching case by id={}", id);
        CaseEntity entity = repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Case not found id=" + id));
        return mapper.toDto(entity);
    }

    @Override
    public CaseResponseDto updateCase(UUID id, CaseRequestDto dto) {
        log.info("Updating case id={}", id);
        CaseEntity existing = repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Case not found id=" + id));

        existing.setCaseName(dto.getCaseName());
        existing.setActive(dto.getActive());
        existing.setCountry(dto.getCountry());
        existing.setRetentionPeriod(dto.getRetentionPeriod());
        existing.setDataSet(dto.getDataSet());

        CaseEntity updated = repository.save(existing);
        log.info("Case updated successfully id={}", id);
        return mapper.toDto(updated);
    }

    @Override
    public void deleteCase(UUID id) {
        log.info("Deleting case id={}", id);
        if (!repository.existsById(id)) {
            throw new NotFoundException("Case not found id=" + id);
        }
        repository.deleteById(id);
        log.info("Case deleted successfully id={}", id);
    }
}
