package com.bnppf.walle.admin.controller;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.service.CaseService;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CaseController.class)
class CaseControllerTest {

    @Autowired private MockMvc mockMvc;
    @MockitoBean
    private CaseService service;

    @Test
    void createCase_ShouldReturn201() throws Exception {
        Mockito.when(service.createCase(Mockito.any()))
                .thenReturn(CaseResponseDto.builder().id(UUID.randomUUID()).caseName("KYC_FR").build());

        mockMvc.perform(post("/case")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            {
                              "caseName": "KYC_FR",
                              "active": true,
                              "country": "FR",
                              "retentionPeriod": 90,
                              "dataSet": ["PID","DOB"]
                            }
                        """))
                .andExpect(status().isCreated());
    }
}
