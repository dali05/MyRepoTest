package com.bnppf.walle.admin.service;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.exception.NotFoundException;
import com.bnppf.walle.admin.mapper.CaseMapper;
import com.bnppf.walle.admin.model.CaseEntity;
import com.bnppf.walle.admin.repository.CaseRepository;
import org.junit.jupiter.api.*;
import org.mockito.*;
import java.util.*;
import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class CaseServiceTest {

    @Mock private CaseRepository repository;
    @Mock private CaseMapper mapper;
    @InjectMocks private CaseServiceImpl service;

    private CaseRequestDto request;
    private CaseEntity entity;
    private CaseResponseDto response;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        request = CaseRequestDto.builder()
                .caseName("KYC_FR")
                .active(true)
                .country("FR")
                .retentionPeriod(90)
                .dataSet(List.of("PID", "DOB"))
                .build();
        entity = CaseEntity.builder().id(UUID.randomUUID()).caseName("KYC_FR").build();
        response = CaseResponseDto.builder().id(entity.getId()).caseName("KYC_FR").build();
    }

    @Test void createCase_ShouldReturnDto() {
        when(mapper.toEntity(request)).thenReturn(entity);
        when(repository.save(entity)).thenReturn(entity);
        when(mapper.toDto(entity)).thenReturn(response);
        assertThat(service.createCase(request)).isNotNull();
    }

    @Test void getCaseById_ShouldThrow_WhenNotFound() {
        when(repository.findById(any())).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> service.getCaseById(UUID.randomUUID()));
    }

    @Test void deleteCase_ShouldThrow_WhenMissing() {
        UUID id = UUID.randomUUID();
        when(repository.existsById(id)).thenReturn(false);
        assertThrows(NotFoundException.class, () -> service.deleteCase(id));
    }
}
