package com.bnppf.walle.admin.controller;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.model.*;
import com.bnppf.walle.admin.service.ConfigService;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;


import java.util.List;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ConfigController.class)
class ConfigControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ConfigService service;

    @Test
    void createConfig_ShouldReturn201() throws Exception {
        ConfigResponseDto mockResponse = ConfigResponseDto.builder()
                .id(UUID.randomUUID())
                .algorithm(Algorithm.ES256)
                .mode(Mode.JWT)
                .build();

        Mockito.when(service.createConfig(Mockito.any())).thenReturn(mockResponse);

        mockMvc.perform(post("/config")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            {
                              "kafkaNotification": true,
                              "notification": "API",
                              "algorithm": "ES256",
                              "mode": "JWT"
                            }
                        """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.algorithm").value("ES256"));
    }

    @Test
    void getAllConfigs_ShouldReturn200() throws Exception {
        Mockito.when(service.getAllConfigs()).thenReturn(List.of());
        mockMvc.perform(get("/config"))
                .andExpect(status().isOk());
    }

    @Test
    void getConfigById_ShouldReturn200() throws Exception {
        UUID id = UUID.randomUUID();
        Mockito.when(service.getConfigById(id))
                .thenReturn(ConfigResponseDto.builder().id(id).algorithm(Algorithm.ES256).build());

        mockMvc.perform(get("/config/" + id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(id.toString()));
    }

    @Test
    void updateConfig_ShouldReturn200() throws Exception {
        UUID id = UUID.randomUUID();
        Mockito.when(service.updateConfig(Mockito.eq(id), Mockito.any()))
                .thenReturn(ConfigResponseDto.builder().id(id).algorithm(Algorithm.ES384).build());

        mockMvc.perform(put("/config/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                        {
                          "kafkaNotification": false,
                          "notification": "KAFKA",
                          "algorithm": "ES384",
                          "mode": "MDOC"
                        }
                    """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.algorithm").value("ES384"));
    }

    @Test
    void deleteConfig_ShouldReturn204() throws Exception {
        UUID id = UUID.randomUUID();
        mockMvc.perform(delete("/config/" + id))
                .andExpect(status().isNoContent());
    }

}
