package com.bnppf.walle.admin.service;

import com.bnppf.walle.admin.dto.*;
import com.bnppf.walle.admin.mapper.ConfigMapper;
import com.bnppf.walle.admin.model.*;
import com.bnppf.walle.admin.repository.ConfigRepository;
import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.data.crossstore.ChangeSetPersister;

import java.util.Optional;
import java.util.UUID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class ConfigServiceTest {

    @Mock
    private ConfigRepository repository;

    @Mock
    private ConfigMapper mapper;

    @InjectMocks
    private ConfigServiceImpl service;

    private ConfigRequestDto request;
    private ConfigEntity entity;
    private ConfigResponseDto response;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        request = ConfigRequestDto.builder()
                .kafkaNotification(true)
                .notification(NotificationType.API)
                .algorithm(Algorithm.ES256)
                .mode(Mode.JWT)
                .build();

        entity = ConfigEntity.builder()
                .algorithm(Algorithm.ES256)
                .mode(Mode.JWT)
                .build();

        response = ConfigResponseDto.builder()
                .id(entity.getId())
                .algorithm(Algorithm.ES256)
                .mode(Mode.JWT)
                .build();
    }

    @Test
    void createConfig_ShouldReturnResponse() {
        when(mapper.toEntity(request)).thenReturn(entity);
        when(repository.save(entity)).thenReturn(entity);
        when(mapper.toDto(entity)).thenReturn(response);

        ConfigResponseDto result = service.createConfig(request);

        assertThat(result).isNotNull();
        assertThat(result.getAlgorithm()).isEqualTo(Algorithm.ES256);
        verify(repository, times(1)).save(entity);
    }

    @Test
    void getConfigById_ShouldReturnConfig() {
        when(repository.findById(any())).thenReturn(Optional.of(entity));
        when(mapper.toDto(entity)).thenReturn(response);

        ConfigResponseDto result = service.getConfigById(UUID.randomUUID());
        assertThat(result).isNotNull();
    }

    @Test
    void getConfigById_ShouldThrowException_WhenNotFound() {
        when(repository.findById(any())).thenReturn(Optional.empty());
        assertThrows(ChangeSetPersister.NotFoundException.class, () -> service.getConfigById(UUID.randomUUID()));
    }

    @Test
    void updateConfig_ShouldUpdateExistingEntity() {
        when(repository.findById(any())).thenReturn(Optional.of(entity));
        when(repository.save(any())).thenReturn(entity);
        when(mapper.toDto(any())).thenReturn(response);

        ConfigResponseDto result = service.updateConfig(UUID.randomUUID(), request);
        assertThat(result).isNotNull();
        verify(repository).save(any());
    }

    @Test
    void deleteConfig_ShouldDeleteSuccessfully() {
        UUID id = UUID.randomUUID();
        when(repository.existsById(id)).thenReturn(true);
        doNothing().when(repository).deleteById(id);

        service.deleteConfig(id);
        verify(repository).deleteById(id);
    }

    @Test
    void deleteConfig_ShouldThrowException_WhenNotFound() {
        UUID id = UUID.randomUUID();
        when(repository.existsById(id)).thenReturn(false);

        assertThrows(ChangeSetPersister.NotFoundException.class, () -> service.deleteConfig(id));
    }

}
